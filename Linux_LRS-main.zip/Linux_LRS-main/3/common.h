#ifndef __COMMON_H__
#define __COMMON_H__

extern void print(char* str);
extern char* input( );

#endif /* __COMMON_H__ */

#!/bin/bash

echo "실행 스크립트: $0"
echo "첫 번째 인자: $1"
echo "인자 개수: $#"
echo "모든 인자(공백으로 구분): $*"
echo "각각의 인자: $@"
